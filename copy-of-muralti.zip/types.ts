
export enum ViewType {
  HOME = '#/home',
  PROFISSIONAIS = '#/profissionais-ti',
  DESENVOLVIMENTO = '#/como-desenvolver',
  ESTAGIOS = '#/estagios-empregos',
  CONCURSOS = '#/concursos',
  EMPREENDEDOR = '#/empreendedorismo',
  PROJETOS = '#/grupos-projetos',
  EVENTOS = '#/eventos-ti',
  VIDEOS = '#/videos-essenciais',
  GALERIA = '#/galeria-fotos',
  LINKS = '#/links-essenciais',
  COORDENADOR = '#/fale-com-o-coordenador',
  CURIOSIDADES = '#/curiosidades-estacio'
}
